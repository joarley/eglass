<ul class="notification-body">
	<li>
		<span>
			<div class="bar-holder no-padding">
				<p class="margin-bottom-5"><i class="fa fa-warning text-warning"></i> <strong>PRIMARY:</strong> <i>Upgrade Infestructure</i> <span class="pull-right semi-bold text-muted">85%</span></p>
				<div class="progress progress-md progress-striped">
					<div class="progress-bar bg-color-teal"  style="width: 85%;"></div>
				</div>
				<em class="note no-margin">last updated on 12/12/2013</em>
			</div>
		</span>
	</li>
	<li>
		<span>
			<div class="bar-holder no-padding">
				<p class="margin-bottom-5"><strong>URGENT:</strong> <i> Code foundation</i> <span class="pull-right semi-bold text-muted">65%</span></p>
				<div class="progress progress-sm">
					<div class="progress-bar bg-color-teal" style="width: 65%;"></div>
				</div>
				<em class="note no-margin">last updated on 12/12/2013</em>
			</div>
		</span>
	</li>
	<li>
		<span>
			<div class="bar-holder no-padding">
				<p class="margin-bottom-5"><strong>URGENT:</strong> <i>Project Plan</i> <span class="pull-right semi-bold text-muted">25%</span></p>
				<div class="progress progress-xs">
					<div class="progress-bar bg-color-teal" style="width: 25%;"></div>
				</div>
				<em class="note no-margin">last updated on 12/12/2013</em>
			</div>
		</span>
	</li>
	<li>
		<span>
			<div class="bar-holder no-padding">
				<p class="margin-bottom-5"><strong>CRITICAL:</strong> <i> Wireframes</i> <span class="pull-right semi-bold text-danger">5%</span></p>
				<div class="progress progress-xs">
					<div class="progress-bar progress-bar-danger" style="width: 5%;"></div>
				</div>
				<em class="note no-margin">last updated on 12/12/2013</em>
			</div>
		</span>
	</li>
	<li>
		<span>
			<div class="bar-holder no-padding">
				<p class="margin-bottom-5"><strong>NORMAL:</strong> <i>Compile hotfix</i> <span class="pull-right semi-bold text-muted">99%</span></p>
				<div class="progress progress-xs">
					<div class="progress-bar progress-bar-success" style="width: 99%;"></div>
				</div>
				<em class="note no-margin">last updated on 12/12/2013</em>
			</div>
		</span>
	</li>
	<li>
		<span>
			<div class="bar-holder no-padding">
				<p class="margin-bottom-5"><strong>MINOR:</strong> <i>Bug fix #213</i><span class="pull-right semi-bold text-muted"><i class="fa fa-check text-success"></i> Complete</span></p>
				<div class="progress progress-micro">
					<div class="progress-bar progress-bar-success" style="width: 100%;"></div>
				</div>
				<em class="note no-margin">last updated on 12/12/2013</em>
			</div>
		</span>
	</li>
	<li>
		<span>
			<div class="bar-holder no-padding">
				<p class="margin-bottom-5"><strong>MINOR:</strong> <i>Bug fix #134</i><span class="pull-right semi-bold text-muted"><i class="fa fa-check text-success"></i> Complete</span></p>
				<div class="progress progress-micro">
					<div class="progress-bar progress-bar-success" style="width: 100%;"></div>
				</div>
				<em class="note no-margin display-inline"><a href="javascript:void(0);">see notes</a></em>
			</div>
		</span>
	</li>
</ul>